// SPDX-License-Identifier: GPL-2.0-or-later
/*****************************************************************************
 * test_zimg_helpers.c - unit tests for the pure helpers in zimg_helpers.h
 *****************************************************************************/

#include "../src/zimg_helpers.h"

#include <limits.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "stripe_bounds_compat.h"


#include "test_harness.h"

/* ---------- round_up_pitch ---------- */

static void test_round_up_pitch_basic(void)
{
    BEGIN("round_up_pitch: rounds up to multiple of 64");
    CHECK_EQ(up_round_up_pitch(0),    0);
    CHECK_EQ(up_round_up_pitch(1),    64);
    CHECK_EQ(up_round_up_pitch(63),   64);
    CHECK_EQ(up_round_up_pitch(64),   64);
    CHECK_EQ(up_round_up_pitch(65),   128);
    CHECK_EQ(up_round_up_pitch(127),  128);
    CHECK_EQ(up_round_up_pitch(128),  128);
    CHECK_EQ(up_round_up_pitch(854),  896);   /* 480p luma */
    CHECK_EQ(up_round_up_pitch(427),  448);   /* 480p chroma */
    CHECK_EQ(up_round_up_pitch(1920), 1920);  /* already aligned */
    CHECK_EQ(up_round_up_pitch(1921), 1984);
    END();
}

static void test_round_up_pitch_negative(void)
{
    BEGIN("round_up_pitch: negative input clamps to 0");
    CHECK_EQ(up_round_up_pitch(-1),   0);
    CHECK_EQ(up_round_up_pitch(-100), 0);
    END();
}

/* ---------- round_up_lines ---------- */

static void test_round_up_lines_basic(void)
{
    BEGIN("round_up_lines: adds 8 rows of padding");
    CHECK_EQ(up_round_up_lines(0),    0);
    CHECK_EQ(up_round_up_lines(1),    9);
    CHECK_EQ(up_round_up_lines(480),  488);
    CHECK_EQ(up_round_up_lines(1080), 1088);
    END();
}

static void test_round_up_lines_negative(void)
{
    BEGIN("round_up_lines: negative input clamps to 0");
    CHECK_EQ(up_round_up_lines(-1), 0);
    END();
}

static void test_round_up_lines_overflow(void)
{
    BEGIN("round_up_lines: rejects overflowing padding");
    int boundary = INT_MAX - UP_SCRATCH_LINE_PAD;
    CHECK_EQ(up_round_up_lines(boundary), INT_MAX);
    CHECK_EQ(up_round_up_lines(boundary + 1), 0);
    CHECK_EQ(up_round_up_lines(INT_MAX), 0);
    END();
}

/* ---------- chroma_dim ---------- */

static void test_chroma_dim_boundaries(void)
{
    BEGIN("chroma_dim: ceil-divides without overflowing");
    CHECK_EQ(up_chroma_dim(INT_MAX, 0), INT_MAX);
    CHECK_EQ(up_chroma_dim(INT_MAX, 1), 1073741824);
    CHECK_EQ(up_chroma_dim(INT_MAX, 16), 32768);
    CHECK_EQ(up_chroma_dim(INT_MAX, 17), 32768);
    CHECK_EQ(up_chroma_dim(8, 1), 4);
    CHECK_EQ(up_chroma_dim(7, 1), 4);
    CHECK_EQ(up_chroma_dim(0, 1), 0);
    CHECK_EQ(up_chroma_dim(8, -1), 0);
    END();
}

/* ---------- plane_pitch ---------- */

static void test_plane_pitch_no_subsample(void)
{
    BEGIN("plane_pitch: sub_w=0 yields full-width pitch");
    CHECK_EQ(up_plane_pitch(854,  0), 896);
    CHECK_EQ(up_plane_pitch(1920, 0), 1920);
    CHECK_EQ(up_plane_pitch(1280, 0), 1280);
    END();
}

static void test_plane_pitch_h_subsample(void)
{
    BEGIN("plane_pitch: sub_w=1 yields half-width pitch");
    CHECK_EQ(up_plane_pitch(854,  1), 448);   /* ceil(427) padded to 448 */
    CHECK_EQ(up_plane_pitch(1920, 1), 960);
    /* odd-width source: ceil to next int, then pitch-align */
    CHECK_EQ(up_plane_pitch(7, 1), 64);       /* (7+1)/2 = 4 -> 64 */
    END();
}

static void test_plane_pitch_quarter_subsample(void)
{
    BEGIN("plane_pitch: sub_w=2 yields quarter-width pitch");
    CHECK_EQ(up_plane_pitch(1920, 2), 512);   /* 480, padded to 512 */
    END();
}

static void test_plane_pitch_zero_neg(void)
{
    BEGIN("plane_pitch: zero/negative input is 0");
    CHECK_EQ(up_plane_pitch(0,  0), 0);
    CHECK_EQ(up_plane_pitch(-1, 0), 0);
    CHECK_EQ(up_plane_pitch(1920, -1), 0);
    END();
}

/* ---------- plane_lines ---------- */

static void test_plane_lines_basic(void)
{
    BEGIN("plane_lines: subsample-aware row count + padding");
    CHECK_EQ(up_plane_lines(480,  0), 488);
    CHECK_EQ(up_plane_lines(480,  1), 248);   /* 240 + 8 pad */
    CHECK_EQ(up_plane_lines(1080, 0), 1088);
    CHECK_EQ(up_plane_lines(1080, 1), 548);
    END();
}

static void test_plane_lines_odd_height(void)
{
    BEGIN("plane_lines: odd height ceils to integer chroma rows");
    /* 7-row source with sub_h=1: ceil(7/2)=4 chroma rows + 8 pad = 12 */
    CHECK_EQ(up_plane_lines(7, 1), 12);
    END();
}

static void test_plane_geometry_extreme_height(void)
{
    BEGIN("plane geometry: propagates extreme-dimension rejection");
    CHECK_EQ(up_plane_pitch(INT_MAX, 0), 0);
    CHECK_EQ(up_plane_pitch(INT_MAX, 1), 1073741824);
    CHECK_EQ(up_plane_lines(INT_MAX, 0), 0);
    CHECK_EQ(up_plane_lines(INT_MAX, 1), 1073741832);
    END();
}

/* ---------- copy_plane ---------- */

static void test_copy_plane_same_stride(void)
{
    BEGIN("copy_plane: stride==row_bytes uses single memcpy fast path");
    uint8_t src[3 * 8] = {0};
    for (int i = 0; i < 24; i++) src[i] = (uint8_t)i;
    uint8_t dst[3 * 8] = {0};
    up_copy_plane(dst, 8, src, 8, 8, 3);
    for (int i = 0; i < 24; i++) CHECK_EQ(dst[i], src[i]);
    END();
}

static void test_copy_plane_different_strides(void)
{
    BEGIN("copy_plane: different strides copies per-row");
    /* src has stride 16 (each row 16 bytes wide, but only first 8 useful) */
    uint8_t src[4 * 16] = {0};
    /* dst has stride 12 */
    uint8_t dst[4 * 12] = {0};
    /* Mark all dst with sentinel. */
    memset(dst, 0xFF, sizeof dst);
    /* Fill src with row-major counter. */
    for (int r = 0; r < 4; r++)
        for (int c = 0; c < 8; c++)
            src[r * 16 + c] = (uint8_t)(r * 100 + c);
    /* Copy 4 rows of 8 bytes from stride-16 src to stride-12 dst. */
    up_copy_plane(dst, 12, src, 16, 8, 4);
    /* Check: bytes [0..8) of each dst row should match src row's first 8;
     * bytes [8..12) should still be 0xFF (sentinel). */
    for (int r = 0; r < 4; r++) {
        for (int c = 0; c < 8; c++)
            CHECK_EQ(dst[r * 12 + c], (uint8_t)(r * 100 + c));
        for (int c = 8; c < 12; c++)
            CHECK_EQ(dst[r * 12 + c], 0xFF);
    }
    END();
}

static void test_copy_plane_zero_rows(void)
{
    BEGIN("copy_plane: rows=0 is no-op");
    uint8_t dst[16];
    memset(dst, 0xAA, 16);
    uint8_t src[16];
    memset(src, 0x55, 16);
    up_copy_plane(dst, 8, src, 8, 8, 0);
    /* dst should be unchanged */
    for (int i = 0; i < 16; i++) CHECK_EQ(dst[i], 0xAA);
    END();
}

static void test_copy_plane_zero_row_bytes(void)
{
    BEGIN("copy_plane: row_bytes=0 is no-op");
    uint8_t dst[16];
    memset(dst, 0xAA, 16);
    uint8_t src[16];
    memset(src, 0x55, 16);
    up_copy_plane(dst, 8, src, 8, 0, 4);
    for (int i = 0; i < 16; i++) CHECK_EQ(dst[i], 0xAA);
    END();
}

static void test_copy_plane_negative_inputs(void)
{
    BEGIN("copy_plane: invalid sizes and strides are no-ops");
    uint8_t dst[16];
    uint8_t src[16];
    memset(src, 0x55, 16);
    memset(dst, 0xAA, 16);
    up_copy_plane(dst, 8, src, 8, -1, 1);
    for (int i = 0; i < 16; i++) CHECK_EQ(dst[i], 0xAA);
    up_copy_plane(dst, 8, src, 8, 8, -1);
    for (int i = 0; i < 16; i++) CHECK_EQ(dst[i], 0xAA);

    const int strides[][2] = {
        { -1, 8 }, { 8, -1 }, { 0, 8 }, { 8, 0 }, { 7, 8 }, { 8, 7 },
    };
    for (size_t i = 0; i < sizeof strides / sizeof *strides; i++) {
        memset(dst, 0xAA, sizeof dst);
        up_copy_plane(dst, strides[i][0], src, strides[i][1], 8, 2);
        for (size_t j = 0; j < sizeof dst; j++) CHECK_EQ(dst[j], 0xAA);
    }
    END();
}

static void test_copy_plane_realistic_480p_luma(void)
{
    BEGIN("copy_plane: realistic 854x480 luma copy");
    /* src has VLC-style pitch 896, visible 854 cols, 480 rows. */
    int src_pitch = 896, dst_pitch = 854, w = 854, h = 480;
    uint8_t *src = malloc(src_pitch * h);
    uint8_t *dst = malloc(dst_pitch * h);
    CHECK(src && dst);
    if (!src || !dst) {
        free(src);
        free(dst);
        END();
        return;
    }
    /* Fill src with a deterministic pattern. */
    for (int r = 0; r < h; r++)
        for (int c = 0; c < src_pitch; c++)
            src[r * src_pitch + c] = (uint8_t)((r * 7 + c * 13) & 0xff);
    memset(dst, 0, dst_pitch * h);
    up_copy_plane(dst, dst_pitch, src, src_pitch, w, h);
    /* Verify each visible pixel matches. */
    for (int r = 0; r < h; r++) {
        for (int c = 0; c < w; c++) {
            CHECK_EQ(dst[r * dst_pitch + c],
                     src[r * src_pitch + c]);
        }
    }
    free(src);
    free(dst);
    END();
}

/* ---------- compute_stripe_bounds ---------- */

static void test_stripe_bounds_n1_full_coverage(void)
{
    BEGIN("stripe_bounds: N=1 covers the entire image in one stripe");
    int sys, sye, dys, dye;
    int ok = stripe_bounds4(0, 1, 480, 1080, &sys, &sye, &dys, &dye);
    CHECK(ok);
    CHECK_EQ(sys, 0);   CHECK_EQ(sye, 480);
    CHECK_EQ(dys, 0);   CHECK_EQ(dye, 1080);
    END();
}

static void test_stripe_bounds_n2_clean_split(void)
{
    BEGIN("stripe_bounds: N=2 on 480x1080 splits exactly at midpoint");
    int sys, sye, dys, dye;
    int ok0 = stripe_bounds4(0, 2, 480, 1080,
                                       &sys, &sye, &dys, &dye);
    CHECK(ok0);
    CHECK_EQ(sys, 0);   CHECK_EQ(sye, 240);
    CHECK_EQ(dys, 0);   CHECK_EQ(dye, 540);
    int ok1 = stripe_bounds4(1, 2, 480, 1080,
                                       &sys, &sye, &dys, &dye);
    CHECK(ok1);
    CHECK_EQ(sys, 240); CHECK_EQ(sye, 480);
    CHECK_EQ(dys, 540); CHECK_EQ(dye, 1080);
    END();
}

static void test_stripe_bounds_full_coverage_n_arbitrary(void)
{
    BEGIN("stripe_bounds: union of stripes covers entire dst for N=1..16");
    for (int n = 1; n <= 16; n++) {
        int last_dst_end = 0;
        int last_src_end = 0;
        for (int i = 0; i < n; i++) {
            int sys, sye, dys, dye;
            int ok = stripe_bounds4(i, n, 480, 1080,
                                              &sys, &sye, &dys, &dye);
            if (!ok) {
                printf("    N=%d i=%d: empty stripe\n", n, i);
                g_cur_fail = 1;
                break;
            }
            CHECK_EQ(dys, last_dst_end);  /* contiguous */
            CHECK_EQ(sys, last_src_end);
            CHECK_EQ((dys & 1), 0);       /* even */
            CHECK_EQ((sys & 1), 0);
            last_dst_end = dye;
            last_src_end = sye;
        }
        CHECK_EQ(last_dst_end, 1080);   /* covers entire dst */
        CHECK_EQ(last_src_end, 480);    /* covers entire src */
    }
    END();
}

static void test_stripe_bounds_invalid_inputs(void)
{
    BEGIN("stripe_bounds: invalid inputs return 0");
    int sys, sye, dys, dye;
    CHECK(!stripe_bounds4(0,  0, 480, 1080, &sys, &sye, &dys, &dye));
    CHECK(!stripe_bounds4(0, -1, 480, 1080, &sys, &sye, &dys, &dye));
    CHECK(!stripe_bounds4(-1, 4, 480, 1080, &sys, &sye, &dys, &dye));
    CHECK(!stripe_bounds4(5,  4, 480, 1080, &sys, &sye, &dys, &dye));
    CHECK(!stripe_bounds4(0,  4,   0, 1080, &sys, &sye, &dys, &dye));
    CHECK(!stripe_bounds4(0,  4, 480,    0, &sys, &sye, &dys, &dye));
    END();
}

/* ---------- up_zimg_stripe_min_lines ---------- */

static void test_zimg_stripe_min_lines_boundaries(void)
{
    BEGIN("up_zimg_stripe_min_lines: 0/negative -> default 16; "
          "positive returns as-is incl VLC range edges");
    /* 0 + negatives: sentinel -> default. */
    CHECK_EQ(up_zimg_stripe_min_lines(0),       UP_STRIPE_MIN_DST_LINES);
    CHECK_EQ(up_zimg_stripe_min_lines(-1),      UP_STRIPE_MIN_DST_LINES);
    CHECK_EQ(up_zimg_stripe_min_lines(INT_MIN), UP_STRIPE_MIN_DST_LINES);
    /* Positive values returned verbatim across the VLC-declared range
     * (1..128), the documented compile-time default (16), and the upper
     * out-of-range value (would be clamped by VLC; tested defensively). */
    CHECK_EQ(up_zimg_stripe_min_lines(1),       1);
    CHECK_EQ(up_zimg_stripe_min_lines(4),       4);    /* lower nominal */
    CHECK_EQ(up_zimg_stripe_min_lines(16),      16);   /* default */
    CHECK_EQ(up_zimg_stripe_min_lines(128),     128);  /* VLC max */
    CHECK_EQ(up_zimg_stripe_min_lines(129),     129);  /* VLC max + 1 */
    CHECK_EQ(up_zimg_stripe_min_lines(INT_MAX), INT_MAX);
    END();
}

static void test_stripe_bounds_ratio_preservation(void)
{
    BEGIN("stripe_bounds: per-stripe ratio close to global ratio");
    /* Global ratio 480/1080 = 0.4444. Each stripe should be within
     * 1/n of that ratio. */
    int n = 4;
    for (int i = 0; i < n; i++) {
        int sys, sye, dys, dye;
        int ok = stripe_bounds4(i, n, 480, 1080,
                                          &sys, &sye, &dys, &dye);
        CHECK(ok);
        int dst_stripe_h = dye - dys;
        int src_stripe_h = sye - sys;
        /* Allow a small drift but no degeneration. */
        CHECK(dst_stripe_h > 0);
        CHECK(src_stripe_h > 0);
        /* Ratio should be within 10% of global 480/1080 ~= 0.444. */
        double ratio = (double)src_stripe_h / dst_stripe_h;
        CHECK(ratio > 0.40 && ratio < 0.49);
    }
    END();
}

/* Source dims default to half the destination — the typical 2x upscale — so
 * these cases keep exercising the dst-driven selection they were written for.
 * The src-bound cases below pass their own geometry. */
static void grid_2x(int n_threads, int dst_w, int dst_h,
                    int stripe_min, int col_min, int *rows, int *cols)
{
    const up_tile_geom_t geom = {
        .src_w = dst_w / 2, .src_h = dst_h / 2,
        .dst_w = dst_w,     .dst_h = dst_h,
    };
    up_decide_tile_grid(n_threads, &geom, stripe_min, col_min, rows, cols);
}

/* SCAL-3 grid: rows*cols <= n, cols>1 only when height-bound. */
static void test_decide_tile_grid(void)
{
    BEGIN("up_decide_tile_grid");
    int r, c;

    /* Tall enough: pure row striping, no columns. */
    grid_2x(8, 1920, 1080, 16, 64, &r, &c);
    CHECK_EQ(r, 8); CHECK_EQ(c, 1);

    /* n_threads <= max_rows (1080/16=67): still cols==1. */
    grid_2x(16, 1920, 1080, 16, 64, &r, &c);
    CHECK_EQ(r, 16); CHECK_EQ(c, 1);

    /* Wide + short: choose the product that uses all 16 workers. */
    grid_2x(16, 1920, 96, 16, 64, &r, &c);
    CHECK_EQ(r, 4); CHECK_EQ(c, 4);
    CHECK(r * c <= 16);

    /* Regression: row-first selection used only 8 of 14 workers. */
    grid_2x(14, 1920, 128, 16, 64, &r, &c);
    CHECK_EQ(r, 7); CHECK_EQ(c, 2);

    /* Equal 12-cell products prefer the grid with more row stripes. */
    grid_2x(13, 192, 96, 16, 64, &r, &c);
    CHECK_EQ(r, 6); CHECK_EQ(c, 2);

    /* Column cap by width: dst_w=80 -> max_cols=80/64=1, so cols stays 1. */
    grid_2x(16, 80, 96, 16, 64, &r, &c);
    CHECK_EQ(r, 6); CHECK_EQ(c, 1);

    /* Degenerate / invalid inputs clamp to >=1 and never overflow the budget.
     * -1, 0, 1, INT_MAX, INT_MIN for each param; the fuzzer sweeps the full
     * cross-product, these pin the contract as a regression guard. */
    grid_2x(0, 0, 0, 16, 64, &r, &c);
    CHECK(r == 1 && c == 1);
    grid_2x(-1, 1920, 96, 16, 64, &r, &c);   /* n<1 -> 1 cell */
    CHECK(r == 1 && c == 1);
    grid_2x(1, 1920, 96, 16, 64, &r, &c);    /* n==1 -> 1 cell */
    CHECK(r == 1 && c == 1);
    grid_2x(16, 1920, 96, -1, 64, &r, &c);   /* stripe_min<=0 */
    CHECK(r >= 1 && c >= 1 && (long long)r * c <= 16);
    grid_2x(16, 1920, 96, 16, 0, &r, &c);    /* col_min<=0 -> cols 1 */
    CHECK_EQ(r, 6); CHECK_EQ(c, 1);
    grid_2x(1000, 8192, 8192, 1, 1, &r, &c);
    CHECK_EQ(r * c, UP_TILE_THREADS_MAX);
    grid_2x(INT_MAX, INT_MAX, INT_MAX, 16, 64, &r, &c);
    CHECK(r >= 1 && c >= 1);
    grid_2x(INT_MIN, INT_MIN, INT_MIN, INT_MIN, INT_MIN, &r, &c);
    CHECK(r == 1 && c == 1);
    END();
}

/* Every cell the grid returns must resolve to a non-degenerate range on both
 * axes — that is the property whose absence killed the backend (REL-2). */
static int grid_cells_all_valid(const up_tile_geom_t *g, int rows, int cols)
{
    up_stripe_bounds_t b;
    for (int i = 0; i < rows; i++)
        if (!up_compute_stripe_bounds(i, rows, g->src_h, g->dst_h, &b))
            return 0;
    for (int i = 0; i < cols; i++)
        if (!up_compute_stripe_bounds(i, cols, g->src_w, g->dst_w, &b))
            return 0;
    return 1;
}

/* REL-2: the grid used to look only at the destination. With a small source
 * and a large destination the dst floors are satisfied while the source stripe
 * rounds to zero rows, up_compute_stripe_bounds returns 0, and the
 * all-or-nothing worker construct fails -> sticky lazy-init failure, every
 * frame dropped (AUTO silently degraded to swscale; --autoupscale-backend=1
 * dropped 100% of frames). */
static void test_decide_tile_grid_src_bound(void)
{
    BEGIN("up_decide_tile_grid: source extent bounds the cell count (REL-2)");
    int r, c;

    /* The reported case: 320x100 -> 1280x400, 64 threads, stripe-lines=4.
     * The old chooser returned 64 rows; 14 of those cells had an empty
     * source range. */
    const up_tile_geom_t reported = { 320, 100, 1280, 400 };
    up_decide_tile_grid(64, &reported, 4, 64, &r, &c);
    CHECK(r <= 50);   /* src_h/2 */
    CHECK(grid_cells_all_valid(&reported, r, c));

    /* Column axis has the same failure mode on a wide-but-narrow source. */
    const up_tile_geom_t narrow_src = { 8, 8, 1920, 96 };
    up_decide_tile_grid(64, &narrow_src, 16, 64, &r, &c);
    CHECK(r <= 4 && c <= 4);
    CHECK(grid_cells_all_valid(&narrow_src, r, c));

    /* A source too small to split at all still yields one usable cell. */
    const up_tile_geom_t tiny_src = { 2, 1, 640, 480 };
    up_decide_tile_grid(32, &tiny_src, 16, 64, &r, &c);
    CHECK_EQ(r, 1); CHECK_EQ(c, 1);
    CHECK(grid_cells_all_valid(&tiny_src, r, c));

    /* Sweep the ratios and thread counts that reach the degenerate region. */
    for (int src_h = 1; src_h <= 64; src_h++)
        for (int n = 1; n <= 64; n += 7)
            for (int sm = 1; sm <= 16; sm += 5)
            {
                const up_tile_geom_t g = { 320, src_h, 1280, 4 * src_h };
                up_decide_tile_grid(n, &g, sm, 64, &r, &c);
                if (!grid_cells_all_valid(&g, r, c)) {
                    printf("    degenerate cell: src_h=%d n=%d sm=%d "
                           "-> %dx%d\n", src_h, n, sm, r, c);
                    g_cur_fail = 1;
                }
            }
    END();
}

/* PAT-1: the io-plan resolver owns the grid/zero-copy invariant chain. */
static void test_resolve_io_plan(void)
{
    BEGIN("up_zimg_resolve_io_plan invariants");
    up_zimg_io_plan_t plan;

    /* Tall frame, both zero-copies on: rows-only, both preserved. */
    up_zimg_io_req_t req = { 8, 960, 540, 1920, 1080, 16, 64, true, true };
    up_zimg_resolve_io_plan(&req, &plan);
    CHECK_EQ(plan.n_rows, 8); CHECK_EQ(plan.n_cols, 1);
    CHECK_EQ(plan.col_tiled, 0);
    CHECK_EQ(plan.src_zerocopy, 1); CHECK_EQ(plan.dst_zerocopy, 1);
    CHECK_EQ(plan.n_threads, plan.n_rows * plan.n_cols);

    /* Wide + short: tiles engage, and col_tiled forces dst copy-out. */
    req = (up_zimg_io_req_t){ 16, 960, 48, 1920, 96, 16, 64, true, true };
    up_zimg_resolve_io_plan(&req, &plan);
    CHECK_EQ(plan.n_rows, 4); CHECK_EQ(plan.n_cols, 4);
    CHECK_EQ(plan.col_tiled, 1);
    CHECK_EQ(plan.src_zerocopy, 1);
    CHECK_EQ(plan.dst_zerocopy, 0);   /* forced off by tiling */

    /* Same geometry without src zero-copy: column tiling is impossible
     * (graphs must read the source directly), grid demotes to rows-only
     * and the dst option survives. */
    req.src_zerocopy = false;
    up_zimg_resolve_io_plan(&req, &plan);
    CHECK_EQ(plan.n_cols, 1);
    CHECK_EQ(plan.col_tiled, 0);
    CHECK_EQ(plan.dst_zerocopy, 1);

    /* Fixed point: resolving a plan's own flags yields the same plan —
     * the property that keeps the open and first-frame call sites
     * consistent with each other. */
    static const up_zimg_io_req_t reqs[] = {
        { 16,  960,   48, 1920,   96, 16, 64, true,  true  },
        { 16,  960,   48, 1920,   96, 16, 64, false, true  },
        {  8,  960,  540, 1920, 1080, 16, 64, true,  false },
        { 64, 3840,   32, 7680,   64, 16, 64, true,  true  },
        {  1,   64,   64,  128,  128, 16, 64, false, false },
        /* REL-2: tiny source, large destination. */
        { 64,  320,  100, 1280,  400,  4, 64, true,  true  },
    };
    for (size_t i = 0; i < sizeof reqs / sizeof reqs[0]; i++) {
        up_zimg_io_plan_t a, b;
        up_zimg_resolve_io_plan(&reqs[i], &a);
        up_zimg_io_req_t again = reqs[i];
        again.src_zerocopy = a.src_zerocopy;
        again.dst_zerocopy = a.dst_zerocopy;
        up_zimg_resolve_io_plan(&again, &b);
        CHECK_EQ(a.n_rows, b.n_rows);
        CHECK_EQ(a.n_cols, b.n_cols);
        CHECK_EQ(a.col_tiled, b.col_tiled);
        CHECK_EQ(a.src_zerocopy, b.src_zerocopy);
        CHECK_EQ(a.dst_zerocopy, b.dst_zerocopy);
    }
    END();
}

int main(void)
{
    printf("Running zimg_helpers tests...\n");

    test_round_up_pitch_basic();
    test_round_up_pitch_negative();
    test_round_up_lines_basic();
    test_round_up_lines_negative();
    test_round_up_lines_overflow();
    test_chroma_dim_boundaries();

    test_plane_pitch_no_subsample();
    test_plane_pitch_h_subsample();
    test_plane_pitch_quarter_subsample();
    test_plane_pitch_zero_neg();

    test_plane_lines_basic();
    test_plane_lines_odd_height();
    test_plane_geometry_extreme_height();

    test_copy_plane_same_stride();
    test_copy_plane_different_strides();
    test_copy_plane_zero_rows();
    test_copy_plane_zero_row_bytes();
    test_copy_plane_negative_inputs();
    test_copy_plane_realistic_480p_luma();

    test_stripe_bounds_n1_full_coverage();
    test_stripe_bounds_n2_clean_split();
    test_stripe_bounds_full_coverage_n_arbitrary();
    test_stripe_bounds_invalid_inputs();
    test_stripe_bounds_ratio_preservation();

    test_zimg_stripe_min_lines_boundaries();
    test_decide_tile_grid();
    test_decide_tile_grid_src_bound();
    test_resolve_io_plan();

    return test_harness_report();
}
