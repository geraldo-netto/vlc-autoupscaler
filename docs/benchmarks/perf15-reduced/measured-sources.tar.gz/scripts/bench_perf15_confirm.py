"""PERF-15 fixed-count randomized confirmation; preserve every capture."""
import argparse
import fcntl
import json
from pathlib import Path
import random
import sys
import time
from types import SimpleNamespace

sys.path.insert(0, str(Path.cwd() / 'scripts'))
import bench_perf15 as bench


def save(path, data):
    temporary = path.with_suffix(path.suffix + '.tmp')
    bench.save(temporary, data)
    temporary.replace(path)


def plan(repeats, treatments, seed):
    generator = random.Random(seed)
    jobs = []
    for repeat in range(repeats):
        names = list(treatments) + (['duplicate'] if repeat % 5 == 0 else [])
        cycle = [(clip, name) for clip in bench.CLIPS for name in names]
        generator.shuffle(cycle)
        for clip, treatment in cycle:
            order = ['baseline', treatment]
            generator.shuffle(order)
            jobs.append(dict(clip=clip, treatment=treatment, repeat=repeat, order=order))
    return jobs


def manifest(args, jobs):
    value = bench.manifest(args)
    value['confirmation'] = dict(plan=jobs, protocol=bench.digest(args.protocol),
                                  runner=bench.digest(Path(__file__)),
                                  repetitions=args.repeats, seed=args.seed)
    return value


def initialize(args, jobs):
    current = manifest(args, jobs)
    path = args.output / 'manifest.json'
    if path.exists():
        if json.loads(path.read_text()) != current:
            raise RuntimeError('sources, inputs or plan changed; cannot resume')
    else:
        save(path, current)
        save(args.output / 'plan.json', jobs)
    return current


def collect_pair(args, job, index):
    directory = args.output / ('pair-%04d' % index)
    completed = directory / 'pair.json'
    if completed.exists():
        return json.loads(completed.read_text())
    if directory.exists():
        raise RuntimeError('incomplete pair retained; inspect before starting a separate study')
    directory.mkdir()
    pair_args = SimpleNamespace(build=args.build, clips=args.clips, output=directory)
    rows = []
    started = time.time()
    result = bench.pair(pair_args, **job, rows=rows)
    result.update(index=index, directory=directory.name, started=started, finished=time.time())
    result['hashes'] = {path.name: bench.digest(path) for path in directory.iterdir() if path.is_file()}
    save(completed, result)
    return result


def verify_evidence(args, rows):
    for row in rows:
        directory = args.output / row['directory']
        for name, expected in row['hashes'].items():
            if bench.digest(directory / name) != expected:
                raise RuntimeError('completed pair evidence changed; reject study')


def compare(args):
    jobs = plan(args.repeats, args.treatments, args.seed)
    before = initialize(args, jobs)
    rows = []
    for index, job in enumerate(jobs):
        rows.append(collect_pair(args, job, index))
        save(args.output / 'pairs.json', rows)
        print('completed', len(rows), '/', len(jobs), flush=True)
    verify_evidence(args, rows)
    if before != manifest(args, jobs):
        raise RuntimeError('measured sources or inputs changed; reject study')
    save(args.output / 'verified.json', dict(hashes_unchanged=True, pairs=len(rows)))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ('build', 'clips', 'output', 'protocol'):
        parser.add_argument(name, type=Path)
    parser.add_argument('--repeats', type=int, default=100)
    parser.add_argument('--seed', type=int, default=20260916)
    parser.add_argument('--treatments', nargs='+', choices=bench.TREATMENTS[1:],
                        default=['local', 'latency'])
    args = parser.parse_args()
    if args.repeats < 100 or len(args.treatments) != len(set(args.treatments)):
        parser.error('require at least 100 repetitions and unique treatments')
    args.output.mkdir(parents=True, exist_ok=True)
    with (args.output / '.lock').open('w') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        compare(args)


if __name__ == '__main__':
    main()
